-- 4212900's Lua and Manifest Created by Morrenus
-- Super Sticker Studio - Creative Fun for Everyone
-- Branch: PUBLIC
-- Created: January 13, 2026 at 04:05:06 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4212900) -- Super Sticker Studio - Creative Fun for Everyone
-- MAIN APP DEPOTS
addappid(4212901, 1, "48b2fd84e5796f27f51dd118ddca4123e3a010b05cfe04f76de31c93dd13f91f") -- Depot 4212901
setManifestid(4212901, "6472071330009522136", 1066217928)